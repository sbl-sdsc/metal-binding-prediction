from setuptools import setup

setup(name='biovec',
      version='0.1',
      description='The implementation of biovec',
      url='https://github.com/kyu999/biovec',
      author='Takashi Kyue',
      author_email='kyukokkyou999@gmail.com',
      license='MIT',
      packages=['biovec'],
      zip_safe=False)
