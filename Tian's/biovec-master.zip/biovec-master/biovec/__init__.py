from .models import ProtVec
